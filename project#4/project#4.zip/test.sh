#!/bin/csh

g++ main.c -o pro4 -O3 -lm -fopenmp 
./pro4
